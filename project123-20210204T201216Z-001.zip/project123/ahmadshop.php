<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
    <title>My Store</title>
    <!--/tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">



    <!--//tags -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/forthebar.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/style6.css" rel="stylesheet" type="text/css" media="all" />

    <!-- //for bootstrap working -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body>



<!-- banner -->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1" class=""></li>
        <li data-target="#myCarousel" data-slide-to="2" class=""></li>
        <li data-target="#myCarousel" data-slide-to="3" class=""></li>
        <li data-target="#myCarousel" data-slide-to="4" class=""></li>
    </ol>
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <div class="container">
                <div class="carousel-caption">
                    <h3>The Biggest <span>Sale</span></h3>
                    <p>Special for today</p>

                </div>
            </div>
        </div>
        <div class="item item2">
            <div class="container">
                <div class="carousel-caption">
                    <h3>Summer <span>Collection</span></h3>
                    <p>New Arrivals On Sale</p>

                </div>
            </div>
        </div>
        <div class="item item3">
            <div class="container">
                <div class="carousel-caption">
                    <h3>The Biggest <span>Sale</span></h3>
                    <p>Special for today</p>

                </div>
            </div>
        </div>
        <div class="item item4">
            <div class="container">
                <div class="carousel-caption">
                    <h3>Summer <span>Collection</span></h3>
                    <p>New Arrivals On Sale</p>
                </div>
            </div>
        </div>
        <div class="item item5">
            <div class="container">
                <div class="carousel-caption">
                    <h3>The Biggest <span>Sale</span></h3>
                    <p>Special for today</p>
                </div>
            </div>
        </div>
    </div>
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    <!-- The Modal -->
</div>
<!--``````````````````````````````````````````````for sign-in,sign-out ``````````````````````````````````````````````````````````````````````````````````````````````-->
<div id="mySidenav" class="sidenav">
    <a href="logout.php" id="logout">log out</a>
    <a id="shareon">
        Share On

        <div class="back" onclick=""><i class="fa fa-facebook" aria-hidden="true"></i></div>

        <div class="back" onclick=""><i class="fa fa-twitter" aria-hidden="true"></i></div>

        <div class="back" onclick=""><i class="fa fa-instagram" aria-hidden="true"></i></div>

        <div class="back" onclick=""><i class="fa fa-linkedin" aria-hidden="true"></i></div>

    </a>

</div>
<!--..............................................for the bar .......................................................................................................-->

<div class="topnav" id="myTopnav">
    <a href="forclientindex.html" class="active" class="fa fa-home">Home</a>
    <a href="about123.html">About</a>
    <a href="men_p.php">For Men</a>
    <a href="woman_P.php">For Women</a>
    <a href="#123">Contact</a>
    <a style="float: right;" href="profilea.php">View Profile</a>

    <a style="color: whitesmoke   ; float: right">
        <form action="#" method="post" class="last">
            <input type="hidden" name="cmd" value="_cart" />
            <input type="hidden" name="display" value="1" />
            <button STYLE="float: right ;background-color: black" class="wview-cart" type="submit" name="submit">
                <span class="fa fa-shopping-cart" aria-hidden="true"></span>
            </button>
        </form>
    </a>
    <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>


<script>
    function myFunction() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }
</script>
<!--**********************************************************for 2 pic************************************************************************************-->

<!--*******************************************************************************************************************************************************-->
<!--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  for sales @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-->
<div class="fornew">
    <p><span>A</span>hmad's shop</p>
</div>
<!--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-->
<!--////////////////////////////////////////////////////////////// for pictuers ///////////////////////////////////////////////////////////////////////////-->
<div class="new_arrivals_agile_w3ls_info">
    <div class="container">
        <div id="horizontalTab">
            <div class="resp-tabs-container">
                <!--/tab_one-->
                <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname= "project0";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$_SESSION['$mm']='1';
$sql="select * from product WHERE sellerid='1' ";
$result=$conn->query($sql);
                while($row= $result->fetch_assoc()) {
                $_SESSION['$pro_id'] = $row ['id'];
              $ad= $name123= $_SESSION['$pro_title'] = $row ['name1'];
                $as=$_SESSION['$pro_price'] = $row ['price'];
                $_SESSION['$pro_desc'] = $row ['discount'];
                $_SESSION['$pro_image'] = $row ['picture'];


                ?>
                <div class="col-md-3 product-men">
                    <div class="men-pro-item simpleCart_shelfItem">
                        <div class="men-thumb-item">
                            <img src="images/<?php echo $_SESSION['$pro_image']?>" alt="" class="pro-image-front">
                            <img src="images/<?php echo $_SESSION['$pro_image']?>" alt="" class="pro-image-back">
                            <div class="men-cart-pro">
                                <div class="inner-men-cart-pro">
                                    <a href="single.html" class="link-product-add-cart">Quick View</a>
                                </div>
                            </div>
                            <span class="product-new-top">New</span>

                        </div>
                        <div class="item-info-product ">
                            <h4><a href="single.html"><?php echo $_SESSION['$pro_title']?></a></h4>
                            <div class="info-product-price">
                                <span class="item_price"><?php echo $_SESSION['$pro_price']?></span>
                                <del><?php echo $_SESSION['$pro_desc']?></del>
                            </div>
                            <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out button2">
                                <form action="cart.php" method="post">
                                    <fieldset>
                                        <input type="hidden" name="cmd" value="_cart" />
                                        <input type="hidden" name="add" value="1" />
                                        <input type="hidden" name="business" value=" " />
                                        <input type="hidden" name="item_name1" value="<?php echo $_SESSION['$pro_title']?>" />
                                        <input type="hidden" name="amount" value="<?php $_SESSION['$pro_price']?>" />
                                        <input type="hidden" name="discount_amount" value="1.00" />
                                        <input type="hidden" name="currency_code" value="USD" />
                                        <input type="hidden" name="return" value=" " />
                                        <input type="hidden" name="cancel_return" value=" " />
                                        <input type="hidden" name="submit" value="Add to cart" class="button" />
                                    </fieldset>



                                </form>
                            </div>

                        </div>



                        <div class="snipcart-details ">
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3l_item" value="Striped Top ">
                                <input style="width: 0px;height: 0px;border-color:white " name="amount" value="<?php echo $_SESSION['$pro_price']?>" >
                                <input style="width: 0px;height: 0px;border-color:white " name="item_name" value="<?php echo $_SESSION['$pro_title']?>" />
                                <button type="submit" class="button w3l-cart" data-id="cart-1">add to cart</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php }?>
                <div class="clearfix"></div>

                <!--//tab_one-->

            </div>
        </div>
    </div>
</div>
</br>
</br>
<!--//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->
<!--....................................... for footer ....................................................................................................-->
<div class="footer" id="123">
    <div class="footer_agile_inner_info_w3l">
        <div class="col-md-3 footer-left">
            <h2><a href="forclientindex.html"><span>M</span>y Store </a></h2>
            <p>In this website you shop in 5 stores.

            </p>
            <P>All the shops in one place</P>
        </div>
        <div class="col-md-9 footer-right">
            <div class="sign-grds">
                <div class="col-md-4 sign-gd">
                    <h4>Our <span>Information</span> </h4>
                    <ul>
                        <li><a href="forclientindex.html">Home</a></li>
                        <li><a href="about123.html">About</a></li>
                        <li><a href="men_p.php">For men</a></li>
                        <li><a href="woman_P.php">For woman</a></li>
                    </ul>
                </div>

                <div class="col-md-5 sign-gd-two">
                    <h4>Admin <span>Information</span></h4>
                    <div class="w3-address">
                        <div class="w3-address-grid">
                            <div class="w3-address-left">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                            </div>
                            <div class="w3-address-right">
                                <h6> Phone Number</h6>
                                <p>+972 594 474 686</p>
                                <p>+972 595 172 950</p>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="w3-address-grid">
                            <div class="w3-address-left">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <div class="w3-address-right">
                                <h6>Email Address</h6>
                                <p>Email :<a href="raya.mah.987@gmail.com"> raya.mah.987@gmail.com</a> </p>
                                <p>Email :<a href="wala.hashayki@gmail.com"> wala.hashayki@gmail.com</a> </p>

                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="w3-address-grid">
                            <div class="w3-address-left">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                            <div class="w3-address-right">
                                <h6>Location</h6>
                                <p>Tunis St,Nablus,Palestine.

                                </p>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="clearfix"></div>

    </div>
</div>
<!-- //footer -->

</div>
<!--.......................................................................................................................................................-->
<script>function hi(){
    alert("some functions will appear after logging in");
}</script>
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="js/jquery-2.2.3.js"></script>
<!-- Custom-JavaScript-File-Links -->

<!-- cart-js -->
<script src="js/minicart.min.js"></script>
<script>
    // Mini Cart
    paypal1.minicart1.render({ //use only unique class names other than paypal1.minicart1.Also Replace same class name in css and minicart.min.js
        action: '#'
    });

    if (~window.location.search.indexOf('reset=true')) {
        paypal1.minicart1.reset();
    }
</script>
<!-- //cart-js -->
</body>
</html>
