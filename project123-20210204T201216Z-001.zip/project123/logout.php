<?php

    session_destroy();
    header('location:http://localhost/project/startpage.html');
?>