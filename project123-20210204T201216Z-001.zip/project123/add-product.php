<?php
session_start();
$msg = "";
$db5 = mysqli_connect("localhost", "root", "", "project0");
// If upload button is clicked ...
if (isset($_POST["upload"])) {
    // Get image name
    $target = "images/".basename($_FILES["image"]["name"]);

    $product_name = $_POST["productn"];
    $product_price=$_POST["productp"];
    $des=$_POST["description"];
    $dis=$_POST["discount"];
    $image1 = $_FILES["image"]["name"];
    $seller=$_SESSION["id"];
    if($_POST["optradio"]=='men') {
        $gender='men';
    }
    if($_POST["optradio"]=='woman') {
        $gender='woman';
    }

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target)) {
        $msg = "Image uploaded successfully";
    }else{
        $msg = "Failed to upload image";
    }


    $sql5 = "INSERT INTO product (price,discount,description,sellerid,picture,name1,gender) 
VALUES ('$product_price','$dis','$des','$seller', '$image1','$product_name','$gender')";
    mysqli_query($db5, $sql5);
    header('location:http://localhost/project/add-product.html');



}
$db5->close();
?>
