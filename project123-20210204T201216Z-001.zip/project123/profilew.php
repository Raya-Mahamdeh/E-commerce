<?php
session_start();
$db330 = mysqli_connect("localhost","root" ,"","project0");
$sql30 = "SELECT  * FROM seller  ";


$result13= $db330->query($sql30);


$flag=false;
if (!$result13) {
    $message  = 'Invalid query: ' . "\n";
    $message .= 'Whole query: ';
    die($message);
}
while ($row = $result13->fetch_assoc())  {

    if (($row["id"] == '0')) {

        $_SESSION["user14"] = $row['firstname'];
        $_SESSION["user24"] = $row['secondname'];
        $_SESSION["id14"] = $row['id'];
        $_SESSION["as4"] = "seller";
        $_SESSION["shopname4"] = $row['shopname'];
        $_SESSION["about4"] = $row['about'];
        $_SESSION["pic4"] = $row['pictuer'];
        $_SESSION["pn4"] = $row['phone'];
        $_SESSION["email4"] = $row['email'];
    }

}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Wala's Profile </title>
    <!--/tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Elite Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //tags -->
    <link href="css/bootstrap1.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
    <link href="css/font-awesome1.css" rel="stylesheet">
    <link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css'/>
    <link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
    <!--//tags -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/forthebar.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/bootstrap3.min.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/cobox.css" rel="stylesheet" type="text/css">
    <link href="css/portfolio.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style3.css" rel="stylesheet" type="text/css" media="all">


    <!-- //for bootstrap working -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<!--/single_page-->
<!-- /banner_bottom_agile_info -->
<div class="page-head_agile_info_w3l">
    <div class="container">
        <h3>Profile <span>Page </span></h3>
        <!--/w3_short-->
        <div class="services-breadcrumb">
            <div class="agile_inner_breadcrumb">

                <ul class="w3_short">
                    <li><a href="forclientindex.html">Home</a><i>|</i></li>
                    <li>Seller Profile Page</li>
                </ul>
            </div>
        </div>
        <!--//w3_short-->
    </div>
</div>
<!--``````````````````````````````````````````````for sign-in,sign-out ``````````````````````````````````````````````````````````````````````````````````````````````-->
<div id="mySidenav" class="sidenav">
    <a href="logout.php" id="logout">log out</a>
    <a id="shareon">
        Share On

        <div class="back" onclick=""><i class="fa fa-facebook" aria-hidden="true"></i></div>

        <div class="back" onclick=""><i class="fa fa-twitter" aria-hidden="true"></i></div>

        <div class="back" onclick=""><i class="fa fa-instagram" aria-hidden="true"></i></div>

        <div class="back" onclick=""><i class="fa fa-linkedin" aria-hidden="true"></i></div>

    </a>

</div>
<!--..............................................for the bar .......................................................................................................-->

<!--..............................................for the bar .......................................................................................................-->

<div class="topnav" id="myTopnav">
    <a href="forclientindex.html" class="active" class="fa fa-home">Home</a>
    <a href="about123.html">About</a>
    <a href="men_p.php">For Men</a>
    <a href="woman_P.php">For Women</a>
    <a href="#12">Contact</a>
    <a style="float: right;" href="#">View Profile</a>
    <div class="asd">

        <a style="color: black ; float: right">

            <form  method="post" action="check.php">

                <input hidden name="raya" id="ashar" >
                <button  style="background-color: black ; color: whitesmoke"type="submit" style="border: none">Check Out</button>

            </form>

        </a>
    </div>
    <a style="color: whitesmoke   ; float: right">
        <form action="#" method="post" class="last">
            <input type="hidden" name="cmd" value="_cart" />
            <input type="hidden" name="display" value="1" />
            <button STYLE="float: right ;background-color: black" class="wview-cart" type="submit" name="submit">
                <span class="fa fa-shopping-cart" aria-hidden="true"></span>
            </button>
        </form>
    </a>

    <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<!--..............................................end the bar .......................................................................................................-->

<div class="about-me" id="about">
    <h3 class="text-center slideanim">About Seller Store</h3>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-xs-12">
                <div class="mydetails slideanim text-center">
                    <img class="img-circle img-responsive" src='images/<?php echo $_SESSION["pic4"] ?>' alt="Generic placeholder image" width="200" height="200">
                    <br>
                    <div>
                        <h3><p><?php echo $_SESSION["shopname4"] ?></p></h3>
                        <p><?php echo $_SESSION["user14"]."  ".$_SESSION["user24"] ?></p>
                    </div>
                    <div class="social-icons">
                        <a href="#"><span class="facebook"></span></a>
                        <a href="#"><span class="twitter"></span></a>
                        <a href="#"><span class="linkedin"></span></a>
                        <a href="#"><span class="googleplus"></span></a>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-xs-12">
                <div class="myskills slideanim">
                    <h3 class="text-center">Information About My Store</h3>
                    <div class="skill-info">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>

                                <tr>
                                    <td><h4>Type Of Product</h4></td>
                                    <td><span class="longline3"></span><span class="shortline3"></span></td>
                                    <td><p><?php echo $_SESSION["about2"] ?></p></td>
                                </tr>

                                <tr>
                                    <td><h4>Phone Number</h4></td>
                                    <td><span class="longline1"></span><span class="shortline1"></span></td>
                                    <td><p><?php echo $_SESSION["pn2"] ?></p></td>
                                </tr>
                                <tr>
                                    <td><h4>Email</h4></td>
                                    <td><span class="longline2"></span><span class="shortline2"></span></td>
                                    <td><p><?php echo $_SESSION["email2"] ?></p></td>
                                </tr>

                                <tr>
                                    <td><h4>Location</h4></td>
                                    <td><span class="longline4"></span><span class="shortline4"></span></td>
                                    <td><p>Nablus, Tunis ST </p></td>
                                </tr>
                                </tbody>
                            </table>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"><br></div>

</div>
<div class="clearfix"><br></div>
<!-- /About -->

<!--....................................... for footer ....................................................................................................-->
<div class="footer" id="12">
    <div class="footer_agile_inner_info_w3l">
        <div class="col-md-3 footer-left">
            <h2><a href="forclientindex.html"><span>M</span>y Store </a></h2>
            <p>In this website you can shop in five stores

            </p>
            <P>All the shops in one place</P>
        </div>
        <div class="col-md-9 footer-right">
            <div class="sign-grds">
                <div class="col-md-4 sign-gd">
                    <h4>Our <span>Information</span> </h4>
                    <ul>
                        <li><a href="forclientindex.html">Home</a></li>
                        <li><a href="about123.html">About</a></li>
                        <li><a href="men_p.php">For men</a></li>
                        <li><a href="woman_P.php">For woman</a></li>

                    </ul>
                </div>

                <div class="col-md-5 sign-gd-two">
                    <h4>Admin <span>Information</span></h4>
                    <div class="w3-address">
                        <div class="w3-address-grid">
                            <div class="w3-address-left">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                            </div>
                            <div class="w3-address-right">
                                <h6> Phone Number</h6>
                                <p>+972 594 474 686</p>
                                <p>+972 595 172 950</p>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="w3-address-grid">
                            <div class="w3-address-left">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <div class="w3-address-right">
                                <h6>Email Address</h6>
                                <p>Email :<a href="raya.mah.123@gmail.com"> raya.mah.123@gmail.com</a></p>
                                <p>Email :<a href="wala.hashayki@gmail.com"> wala.hashayki@gmail.com</a> </p>

                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="w3-address-grid">
                            <div class="w3-address-left">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                            <div class="w3-address-right">
                                <h6>Location</h6>
                                <p>Tunis St,Nablus,Palestine.

                                </p>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="clearfix"></div>

    </div>
</div>
<!-- //footer -->

<?php
$db330->close();
?>

<!-- /footer -->
<!-- js files -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- js files for banner slider -->
<script src="js/responsiveslides.min.js"></script>
<script>
    $(window).load(function() {

        // Slideshow for banner
        $("#slider").responsiveSlides({
            maxwidth: 1920,
            speed: 1000
        });


    });
</script>
<!-- /js files for banner slider -->
<!-- js files for portfolio -->
<script src="js/classie.js"></script>
<script src="js/helper.js"></script>
<script src="js/grid3d.js"></script>
<script>
    new grid3D( document.getElementById( 'grid3d' ) );
</script>
<!-- /js files for portfolio -->
<!-- js files for gallery -->
<script type="text/javascript" src="js/cobox.js"></script>
<!-- /js files for gallery -->
<!-- js for smooth scrolling -->

<script>
    $(document).ready(function(){
        // Add smooth scrolling to all links in navbar + footer link
        $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 900, function(){

                // Add hash (#) to URL when done scrolling (default click behavior)
                window.location.hash = hash;
            });
        });
    })

</script>
<!-- /js for smooth scrolling -->
<!-- js for sliding -->

<script>
    $(window).scroll(function() {
        $(".slideanim").each(function(){
            var pos = $(this).offset().top;

            var winTop = $(window).scrollTop();
            if (pos < winTop + 600) {
                $(this).addClass("slide");
            }
        });
    });
</script>
<!-- /js for sliding -->
<!-- /js files -->

</body>
</html>
