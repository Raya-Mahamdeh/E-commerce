<?php

session_start();

if(isset($_POST['signup']))
{

    $firstname=$_POST['firstname'];
    $secondname=$_POST['secondname'];
    $phone=$_POST['phonenumber'];
    $address=$_POST['address'];
    $email=$_POST['email'];
    $phonenumber=$_POST['phonenumber'];
    $password=sha1($_POST['password']);
    $confirmpassword=$_POST['confirmpassword'];
    $db = mysqli_connect("localhost","root" ,"","project0");


    if($password == $confirmpassword){
        $sql="select * from client where 1";}
    $flag = false;
    $r = $db->query($sql);
    while($row = mysqli_fetch_assoc($r)){
        if($row['email'] == $email){
            $flag = true;
            break;
        }
    }
    if ($flag == true){
        header('location :http://localhost/project/sinup.php.html');
    } else {
        $sql1 = "INSERT INTO client (firstname,secondname,email,password,phone,address)
VALUES('$firstname','$secondname','$email','$password','$phone','$address')";}

    mysqli_query($db,$sql1);
    header("location:http://localhost/project/forclientindex.html");
}
$db->close();
?>