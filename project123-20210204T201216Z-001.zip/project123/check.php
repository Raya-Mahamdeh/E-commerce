
<?php
session_start();
$r=$_POST["raya"];
$dbf = mysqli_connect("localhost", "root", "", "project0");

if (isset($_POST["submit0"])) {



    $sqlf = "INSERT INTO clientorder (amount) 
VALUES ('$r')";
    mysqli_query($dbf, $sqlf);
    header('location:http://localhost/project/forclientindex.html');



}
$dbf->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order</title>
    <!--/tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Elite Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //tags -->
    <link href="css/bootstrap1.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
    <link href="css/font-awesome1.css" rel="stylesheet">
    <link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css'/>
    <link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
    <!--//tags -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/forthebar.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/bootstrap3.min.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/cobox.css" rel="stylesheet" type="text/css">
    <link href="css/portfolio.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style3.css" rel="stylesheet" type="text/css" media="all">


    <!-- //for bootstrap working -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<!--/single_page-->
<!-- /banner_bottom_agile_info -->
<div class="page-head_agile_info_w3l">
    <div class="container">
        <h3>Order<span>Page </span></h3>
        <!--/w3_short-->
        <div class="services-breadcrumb">
            <div class="agile_inner_breadcrumb">

                <ul class="w3_short">
                    <li><a href="forclientindex.html">Home</a><i>|</i></li>
                    <li>Order Page</li>
                </ul>
            </div>
        </div>
        <!--//w3_short-->
    </div>
</div>

<!--..............................................for the bar .......................................................................................................-->
<div class="topnav" id="myTopnav">
    <a href="forclientindex.html" class="active" class="fa fa-home">Home</a>
    <a href="about123.html">About</a>
    <a href="men_p.php">For Men</a>
    <a href="woman_P.php">For Women</a>
    <a href="#contact">Contact</a>

    <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<div class="clearfix"><br><br></div>
<!--..............................................end the bar .......................................................................................................-->




<div class="container">
    <div class="row justify-content-md-center">
        <div class="col col-sm-3"></div>
        <div class="col-sm-6">

            <h3 style="color: #1b6d85 ; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; "> Your Total Bill</h3>

            <div class="clearfix"><br>   </div>



            <form class="form-horizontal" role="form" method="post" action="">

                <div class="form-group">
                    <label for="name" class="col-sm-2 control-label">Total Bill</label>
                    <div class="col-sm-10">
                        <label class="form-control" id="name1" name="name0" placeholder="final bill"><?php echo $r?></label>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-10 col-sm-offset-2">
                        <input id="submit" name="submit0" type="submit" value="Finsh order" class="btn btn-primary">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-10 col-sm-offset-2">
                        <! Will be used to display an alert to the user>
                    </div>
                </div>
            </form>
            <div class="clearfix"><br></div>

        </div>

    </div>
</div>


</body>
</html>
