function check() {
    var c = document.getElementsByClassName("minicart1-subtotal")[0].innerHTML.toString();
    document.getElementById("ashar").setAttribute("value",c);

}