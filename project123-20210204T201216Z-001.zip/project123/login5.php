<?php

session_start();
$db1 = mysqli_connect("localhost","root" ,"","project0");

//mysqli_select_db('project0', $db1) or die(mysqli_error());
//if(isset($_POST['login']))
//{

$email = $_POST["TXemail"];
$password = $_POST["TXpassword"];


#$email= "ahmad.ali.123@gmail.com";
#$password = "ahmad123";

$password = substr(sha1($password), 0, 30);

    $sql2 = "SELECT  * FROM client WHERE email ='$email' and password ='$password' ";


$result = $db1->query($sql2);
#$num = $result->num_rows;

$flag=false;
if (!$result) {
    $message  = 'Invalid query: ' . "\n";
    $message .= 'Whole query: ';
    die($message);
}

while ($row = $result->fetch_assoc())  {
   if (($row["email"] == $email) && ($row['password'] == $password)) {
        $_SESSION["logged"] = 1;
        $_SESSION["user1"] = $row['firstname'];
        $_SESSION["user2"] = $row['secondname'];
        $_SESSION["id"] = $row['id'];
        $_SESSION["as"] = "client";

        header('location:http://localhost/project/forclientindex.html');


    }
}

$db1->close();
?>


