<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Store</title>
    <!--/tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="new1.js"></script>



    <!--//tags -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/forthebar.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all"/>
    <!-- //for bootstrap working -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body>
<div>band</div>
<div class="topnav" id="myTopnav">
    <a href="#home">Home</a>
    <a href="#about">About</a>
</div>
<div class="fornew">
    <p><span>W</span>hat is NEW</p>
</div>
<!--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-->
<!--////////////////////////////////////////////////////////////// for pictuers ///////////////////////////////////////////////////////////////////////////-->

<div class="new_arrivals_agile_w3ls_info">
    <div class="container">
        <div id="horizontalTab">
            <div class="resp-tabs-container">
                <!--/tab_one-->
                <div class="tab1">
                    <div id="get_prodect"></div>
                    <!--<div class="col-md-3 product-men">
                        <div class="men-pro-item simpleCart_shelfItem">
                            <div class="men-thumb-item">
                                <img src="images/m1.jpg" alt="" class="pro-image-front">
                                <img src="images/m1.jpg" alt="" class="pro-image-back">
                                <div class="men-cart-pro">
                                    <div class="inner-men-cart-pro">
                                        <a href="single.html" class="link-product-add-cart">Quick View</a>
                                    </div>
                                </div>
                                <span class="product-new-top">New</span>

                            </div>
                            <div class="item-info-product ">
                                <h4><a href="single.html">Formal Blue Shirt</a></h4>
                                <div class="info-product-price">
                                    <span class="item_price">$45.99</span>
                                    <del>$69.71</del>
                                </div>
                                <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out button2">
                                    <form action="#" method="post">
                                        <fieldset>
                                            <input type="hidden" name="cmd" value="_cart" />
                                            <input type="hidden" name="add" value="1" />
                                            <input type="hidden" name="business" value=" " />
                                            <input type="hidden" name="item_name" value="Formal Blue Shirt" />
                                            <input type="hidden" name="amount" value="30.99" />
                                            <input type="hidden" name="discount_amount" value="1.00" />
                                            <input type="hidden" name="currency_code" value="USD" />
                                            <input type="hidden" name="return" value=" " />
                                            <input type="hidden" name="cancel_return" value=" " />
                                            <input type="submit" name="submit" value="Add to cart" class="button" />
                                        </fieldset>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>-->

                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</br>
<div class="wrapper">
    <a href="#" class="previous round">&#8249;</a>
    <a href="#" class="next round">&#8250;</a>
</div>
</br>
</br>
<a class="hhh" href="#11"><i class="fa fa-angle-double-up fa-4x" ></i></a>
</body>
</html>